from odoo import models, fields, api, _
from odoo.exceptions import UserError

class GdexWizard(models.TransientModel):
    _name='motogene.gdex.wizard'
    _description='GDEX Normal Bulk Wizard'
    line_ids=fields.One2many('motogene.gdex.wizard.line','wizard_id',string='Shipments')
    consignment_ids=fields.Many2many('motogene.gdex.consignment',string='Created Consignments')
    results=fields.Text(readonly=True)

    def load_pickings(self,pickings):
        self.ensure_one()
        vals=[]
        for p in pickings:
            partner=p.partner_id
            addr=', '.join(x for x in [partner.street,partner.street2,partner.city] if x)
            vals.append((0,0,{'picking_id':p.id,'receiver_name':partner.name,'receiver_mobile':partner.mobile or partner.phone,
                              'receiver_address1':addr,'receiver_postcode':partner.zip,'weight':1.0,'pieces':1}))
        self.line_ids=vals

    def action_create(self):
        self.ensure_one()
        results=[]; cons=self.env['motogene.gdex.consignment']
        for line in self.line_ids:
            p=line.picking_id
            if line.consignment_id:
                line.result='Already processed in this wizard; review existing attempt'
                continue
            if p.state!='assigned' or p.x_studio_order_type!='Normal':
                line.result='Blocked: Only Ready / Normal Delivery allowed';continue
            if p.mori_awb_no:
                line.result='Blocked: AWB already present';continue
            previous=cons.search([('picking_id','=',p.id),('state','in',('success','uncertain'))],limit=1)
            if previous:
                line.result='Blocked: successful or uncertain previous request';continue
            c=cons.create({'picking_id':p.id,'receiver_name':line.receiver_name,
                'receiver_mobile':line.receiver_mobile,'receiver_address1':line.receiver_address1,
                'receiver_postcode':line.receiver_postcode,'weight':line.weight,'pieces':line.pieces})
            c.action_create()
            line.consignment_id=c.id
            line.result=(c.state.upper()+': '+(c.awb or c.error_message or ''))[:400]
            results.append(c)
        self.consignment_ids=[(6,0,[x.id for x in results])]
        self.results='\n'.join(l.picking_id.name+': '+(l.result or '') for l in self.line_ids)
        return {'type':'ir.actions.act_window','res_model':self._name,'res_id':self.id,'view_mode':'form','target':'new'}

    def action_print_results(self):
        self.ensure_one()
        cons=self.line_ids.mapped('consignment_id').filtered(lambda c:c.state=='success')
        return cons.action_print_bulk()

class GdexWizardLine(models.TransientModel):
    _name='motogene.gdex.wizard.line'
    _description='GDEX Wizard Shipment'
    wizard_id=fields.Many2one('motogene.gdex.wizard',ondelete='cascade',required=True)
    picking_id=fields.Many2one('stock.picking',readonly=True)
    receiver_name=fields.Char()
    receiver_mobile=fields.Char()
    receiver_address1=fields.Char()
    receiver_postcode=fields.Char()
    weight=fields.Float(default=1)
    pieces=fields.Integer(default=1)
    result=fields.Char(readonly=True)
    consignment_id=fields.Many2one('motogene.gdex.consignment',readonly=True)
