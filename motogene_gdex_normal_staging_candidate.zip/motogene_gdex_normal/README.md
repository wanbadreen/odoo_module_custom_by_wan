# MotoGene GDEX Normal — Odoo 18 staging candidate

Standalone integration for manual single/bulk Normal DO AWB, partial success, GDEX sandbox connection and 100x150 PDF.

## SAFETY
- Sandbox only; production API is intentionally disabled.
- Test in isolated staging and assign **GDEX Normal Operator** to authorized staff.
- `mori_awb_no` and `x_studio_order_type` are existing Odoo Studio fields and must exist before installation.
- Credentials in `ir.config_parameter` are restricted at UI level but **not encrypted at rest**; ensure appropriate admin/database access controls.
- The `action_create` code commits a pending/uncertain record before submitting a network request to minimize duplicate AWBs after timeout. This is intentional but requires review against your Odoo.sh transaction policy.
- Retry is deliberately **not automatic** after uncertain outcomes. Verify in GDEX portal first.
- Optional fields deferred as agreed.
- PDF uses PyMuPDF (`fitz`) to crop A4 top-left GDEX A6 layout to 100x150mm and `pypdf` for merging. Confirm dependencies installed on Odoo.sh.
- API request/label are tested only on supplied sandbox examples; complete integration test is still required.

## QA
1. Install on staging with `x_studio_order_type` and `mori_awb_no` available.
2. Configure Sandbox token and subscription key in Settings, test connection.
3. Verify single Normal ready DO and COD/other blocked cases.
4. Verify bulk mixed DOs, missing fields, duplicate AWBs, timeout uncertain cases.
5. Verify generated PDF and scanner readability; verify multi-page PDF print 100x150mm.
6. Check Odoo.sh logs for installation/view/schema errors before progressing.

## Known prerequisites / items requiring QA
- Confirm Odoo 18 view IDs and security group category refs in your running database.
- Confirm `fitz` and `pypdf` exist in the Odoo.sh Python environment.
- Crop rectangle currently assumes GDEX A6 template occupies top-left approx 300x405pt; compare test print against provided successful reference and adjust in `models/consignment.py` if needed.
- Printing existing successful AWBs from another wizard run is available in Consignments list/form; extend UI with bulk action later if needed.
- Production configuration and deployment intentionally locked pending independent approval.
