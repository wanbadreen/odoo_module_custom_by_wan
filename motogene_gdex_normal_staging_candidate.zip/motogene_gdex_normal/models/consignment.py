import base64
import io
import logging
import requests
from odoo import models, fields, api, _
from odoo.exceptions import UserError
from .config import DEMO
_logger = logging.getLogger(__name__)

class GdexConsignment(models.Model):
    _name = 'motogene.gdex.consignment'
    _description = 'GDEX Normal Consignment Attempt'
    _order = 'id desc'

    picking_id = fields.Many2one('stock.picking',required=True,index=True,ondelete='restrict')
    state = fields.Selection([('draft','Draft'),('success','Success'),('failed','Failed'),('uncertain','Unknown - Verify in Portal')],required=True,default='draft',index=True)
    awb = fields.Char(readonly=True,copy=False)
    receiver_name = fields.Char()
    receiver_mobile = fields.Char()
    receiver_address1 = fields.Char()
    receiver_postcode = fields.Char()
    weight = fields.Float(default=1.0)
    pieces = fields.Integer(default=1)
    error_message = fields.Text(readonly=True)
    request_reference = fields.Char(readonly=True)
    created_by_id = fields.Many2one('res.users', default=lambda s:s.env.user,readonly=True)
    pdf_attachment_id = fields.Many2one('ir.attachment',readonly=True,copy=False)

    def _connection(self):
        self.ensure_one()
        p=self.env['ir.config_parameter'].sudo()
        if p.get_param('motogene_gdex_normal.environment','sandbox') != 'sandbox':
            raise UserError(_('Production requests are locked.'))
        token=p.get_param('motogene_gdex_normal.sandbox_token')
        key=p.get_param('motogene_gdex_normal.sandbox_key')
        if not token or not key:
            raise UserError(_('Missing GDEX Sandbox credentials in Settings.'))
        return {'ApiToken':token,'Subscription-Key':key}

    def action_create(self):
        for rec in self:
            if rec.state in ('success','uncertain'):
                continue
            p=rec.picking_id
            # Lock the DO row until the pending marker is durably written.
            # A second concurrent worker waits and then sees the uncertain attempt.
            self.env.cr.execute('SELECT id FROM stock_picking WHERE id = %s FOR UPDATE', (p.id,))
            if p.state != 'assigned' or p.x_studio_order_type != 'Normal':
                rec.write({'state':'failed','error_message':'DO must be Ready and Normal Delivery.'})
                continue
            if p.mori_awb_no or self.search_count([('picking_id','=',p.id),('state','in',('success','uncertain')),('id','!=',rec.id)]):
                rec.write({'state':'failed','error_message':'DO already has an AWB or unresolved GDEX attempt.'})
                continue
            if not all((rec.receiver_name,rec.receiver_mobile,rec.receiver_address1,rec.receiver_postcode)) or rec.weight <= 0 or not 1 <= rec.pieces <= 30:
                rec.write({'state':'failed','error_message':'Missing receiver fields or invalid weight/pieces.'})
                continue
            if not p.partner_id.country_id or p.partner_id.country_id.code != 'MY':
                rec.write({'state':'failed','error_message':'Only Malaysia domestic delivery supported.'})
                continue
            try:
                headers=rec._connection()
                headers.update({'Content-Type':'application/json-patch+json','Accept':'application/json'})
                payload=[{'shipmentType':'Parcel','totalPiece':rec.pieces,'shipmentWeight':rec.weight,
                          'receiverName':rec.receiver_name,'receiverMobile':rec.receiver_mobile,
                          'receiverAddress1':rec.receiver_address1,'receiverPostcode':rec.receiver_postcode,
                          'receiverCountry':'Malaysia','isDangerousGoods':False,'IsInsurance':False,
                          'isCod':False,'orderID':p.name[:60]}]
                params=self.env['ir.config_parameter'].sudo()
                account=params.get_param('motogene_gdex_normal.account_no')
                # Mark pending before network call and commit to avoid duplicate requests on an HTTP timeout.
                rec.write({'state':'uncertain','error_message':'Request sent or pending verification in GDEX portal.'})
                self.env.cr.commit()
                response=requests.post(DEMO+'/CreateConsignment',params={'accountNo':account} if account else None,
                                       headers=headers,json=payload,timeout=35)
                try: data=response.json()
                except ValueError: data={}
                awbs=data.get('r')
                if response.status_code == 200 and data.get('s') == 'success' and isinstance(awbs,list) and len(awbs)==1 and awbs[0]:
                    awb=str(awbs[0])
                    # Prevent silently overwriting another AWB from another workflow.
                    p.invalidate_recordset(['mori_awb_no'])
                    if p.mori_awb_no:
                        rec.write({'state':'uncertain','awb':awb,'error_message':'GDEX returned AWB but DO field occupied; review manually.'})
                    else:
                        p.write({'mori_awb_no':awb})
                        rec.write({'state':'success','awb':awb,'error_message':False})
                elif response.status_code in (400,401,403) and data.get('s') == 'fail':
                    rec.write({'state':'failed','error_message':str(data.get('e') or 'Rejected by API')[:500]})
                else:
                    rec.write({'state':'uncertain','error_message':'Unexpected API response; verify in GDEX portal before retry.'})
            except requests.RequestException as e:
                rec.write({'state':'uncertain','error_message':'Network/timeout ('+type(e).__name__+'). Check portal; retry blocked.'})
            except UserError as e:
                rec.write({'state':'failed','error_message':str(e)[:500]})
        return True

    def _ensure_pdf(self):
        self.ensure_one()
        if self.state != 'success' or not self.awb:
            raise UserError(_('Only successful consignments may be printed.'))
        if self.pdf_attachment_id:
            return base64.b64decode(self.pdf_attachment_id.datas)
        headers=self._connection()
        try:
            response=requests.get(DEMO+'/GetConsignmentNotePDF',headers=headers,
                params={'consignmentNo':self.awb,'paperPrintingSize':'A6'},timeout=35)
        except requests.RequestException as exc:
            raise UserError(_('GDEX PDF request failed (%s)') % type(exc).__name__) from exc
        if response.status_code != 200 or not response.content.startswith(b'%PDF'):
            raise UserError(_('GDEX did not return a PDF (HTTP %s).') % response.status_code)
        import fitz
        src=fitz.open(stream=response.content,filetype='pdf')
        if len(src)!=1:
            raise UserError(_('Expected a single-page GDEX PDF.'))
        page=src[0]
        # A6 layout supplied by GDEX is a label in the top-left of an A4 PDF.
        # Crop to its dotted 105x142 mm boundary, then proportionally fit 100x150.
        crop=fitz.Rect(0,0,min(page.rect.width,300),min(page.rect.height,405))
        dst=fitz.open()
        dst_page=dst.new_page(width=100*72/25.4,height=150*72/25.4)
        margin=4*72/25.4
        usable=fitz.Rect(margin,margin,dst_page.rect.width-margin,dst_page.rect.height-margin)
        ratio=min(usable.width/crop.width,usable.height/crop.height)
        w,h=crop.width*ratio,crop.height*ratio
        target=fitz.Rect((dst_page.rect.width-w)/2,(dst_page.rect.height-h)/2,(dst_page.rect.width+w)/2,(dst_page.rect.height+h)/2)
        dst_page.show_pdf_page(target,src,0,clip=crop)
        out=dst.tobytes(garbage=4,deflate=True)
        dst.close();src.close()
        attachment=self.env['ir.attachment'].sudo().create({'name':self.awb+'_100x150.pdf','type':'binary',
           'datas':base64.b64encode(out),'mimetype':'application/pdf','res_model':self._name,'res_id':self.id})
        self.pdf_attachment_id=attachment.id
        return out

    def action_print_single(self):
        self.ensure_one()
        self._ensure_pdf()
        return {'type':'ir.actions.act_url','url':'/web/content/%s?download=true' % self.pdf_attachment_id.id,'target':'self'}

    def action_print_bulk(self):
        from pypdf import PdfReader, PdfWriter
        writer=PdfWriter(); lines=self.filtered(lambda r:r.state=='success')
        if not lines: raise UserError(_('No successful GDEX AWB found.'))
        for rec in lines:
            reader=PdfReader(io.BytesIO(rec._ensure_pdf()))
            for p in reader.pages: writer.add_page(p)
        stream=io.BytesIO();writer.write(stream)
        attachment=self.env['ir.attachment'].sudo().create({'name':'GDEX_Bulk_AWB_100x150.pdf','type':'binary',
            'datas':base64.b64encode(stream.getvalue()),'mimetype':'application/pdf'})
        return {'type':'ir.actions.act_url','url':'/web/content/%s?download=true' % attachment.id,'target':'self'}
